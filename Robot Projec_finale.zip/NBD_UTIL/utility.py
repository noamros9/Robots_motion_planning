from arr2_epec_cs_ex import *
import NBD_UTIL.drrt_ao as drrt_ao
import NBD_UTIL.heuristic as heuristic
from NBD_UTIL.walk_path import walk_best_path
import NBD_UTIL.conversions as conversions
import NBD_UTIL.Collision_detection as Collision_detection
import random
import NBD_UTIL.circle_triangle_collision as circle_triangle_collision


def get_coupon_point(bonuses, i, radius, obstacles):
    cd = Collision_detection.Collision_detector(obstacles, radius)
    cx = 0
    cy = 0
    tups = conversions.polygon_2_to_tuples_list(bonuses[i][0])
    for j in range(3):
        cx += tups[j][0]
        cy += tups[j][1]
    cx = cx / 3
    cy = cy / 3
    p = conversions.xy_to_point_2(cx, cy)
    while (not cd.is_point_valid(p)) or (
    not circle_triangle_collision.is_circle_collide_triangle(conversions.point_2_to_xy(p), radius.to_double(), tups)):
        rand_x = random.uniform(-radius.to_double(), radius.to_double())
        rand_y = random.uniform(-radius.to_double(), radius.to_double())
        p = conversions.xy_to_point_2(cx + rand_x, cy + rand_y)
    return p



def coupon_selection(radius, team_robots, team_objectives, obstacles, bonuses):
    mn = min(len(team_robots), len(bonuses))
    team_objectives_coup = list(team_objectives)
    for i in range(mn):
        team_objectives_coup[i] = get_coupon_point(bonuses, i, radius, obstacles)
    return team_objectives_coup

def team_init(teamcoup, teamgoal, params, ts):
    teamcoup.graphs_single_robots, teamcoup.trees_single_robots, result1 = drrt_ao.calculate_consituent_roadmaps(teamcoup)
    teamgoal.graphs_single_robots, teamgoal.trees_single_robots, result2 = drrt_ao.calculate_consituent_roadmaps(
        teamgoal)
    if result1 and result2:
        teamcoup_heuristic_obj = heuristic.makeHeuristic(teamcoup.graphs_single_robots)
        teamgoal_heuristic_obj = heuristic.makeHeuristic(teamgoal.graphs_single_robots)
        total_nodes = 0
        for i in range(len(teamcoup.team_robots)):
            total_nodes += len(teamcoup.graphs_single_robots[i].nodes) + len(teamgoal.graphs_single_robots[i].nodes)
        teamcoup.g_tensor = drrt_ao.find_path_drrtAst(teamcoup, teamcoup_heuristic_obj, 0, ts, total_nodes)
        best_path = teamcoup.g_tensor.best_path
        teamgoal.g_tensor = drrt_ao.find_path_drrtAst(teamgoal, teamgoal_heuristic_obj, 1, ts, total_nodes)
        best_path.extend(teamgoal.g_tensor.best_path)
        teamcoup.g_tensor.best_path = best_path
        data = [teamcoup]
        params[11].append(data)
    else:
        teamcoup.team_objectives = teamgoal.team_objectives
        teamcoup.graphs_single_robots, teamcoup.trees_single_robots, result = drrt_ao.calculate_consituent_roadmaps(
            teamcoup)
        if not result:
            print("we surrender")
            teamcoup.g_tensor.append(teamcoup.team_robots)
            data = [teamcoup]
            params[11].append(data)
            return
        teamcoup_heuristic_obj = heuristic.makeHeuristic(teamcoup.graphs_single_robots)
        total_nodes = 0
        for i in range(len(teamcoup.team_robots)):
            total_nodes += len(teamcoup.graphs_single_robots[i].nodes)
        teamcoup.g_tensor = drrt_ao.find_path_drrtAst(teamcoup, teamcoup_heuristic_obj, 0, ts, total_nodes)
        data = [teamcoup]
        params[11].append(data)
def team_play_turn(params):
    team_status = params[1]
    opponent_status = params[2]
    bonuses = params[3]
    data = params[4]
    remaining_time = params[5]
    team = data[0][0]
    if remaining_time < team.turn_time:
        team.turn_time = remaining_time
    for i in range(len(team.team_robots)):
        team.team_robots[i] = team_status[i][0]
    path = walk_best_path(team, opponent_status)
    params[0].extend(path)


