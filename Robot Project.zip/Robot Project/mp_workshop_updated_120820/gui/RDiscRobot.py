from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtOpenGL import QGLWidget, QGLFormat, QGL
from PyQt5.QtWidgets import (QApplication, QGraphicsView,
                             QGraphicsPixmapItem, QGraphicsScene, QGraphicsPolygonItem,
                             QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsTextItem, QOpenGLWidget)
from PyQt5.QtGui import QPainter, QPixmap, QPolygonF, QPen, QFont, QTransform
from PyQt5.QtCore import (QObject, QPointF, QPoint, QRectF,
                          QPropertyAnimation, pyqtProperty, QSequentialAnimationGroup,
                          QParallelAnimationGroup, QPauseAnimation, Qt)


class RDiscRobot(QObject):
    def __init__(self, r: float, x: float, y: float, color, line_width: float, text=""):
        self._visible = 1
        self._radius = r
        self._pos = QPointF(x, y)
        super().__init__()
        # The supporting rectangle
        self.rect = QRectF(x - r, y - r, 2 * r, 2 * r)
        # The underlying QGraphicsEllipseItem
        self.disc = QGraphicsEllipseItem()
        self.disc.setRect(self.rect)
        self.disc.setBrush(QtGui.QBrush(color))
        # The underlying QGraphicsTextItem
        self.text: QGraphicsTextItem = QGraphicsTextItem(text)
        transform = QTransform.fromScale(0.3, -0.3)
        self.text.setTransformOriginPoint(self._pos)
        self.text.setTransform(transform)
        self.text.setPos(QPointF(x - 1.8, y + 1.8))
        font = QFont("Times", 1)
        self.text.setFont(font)
        pen = QPen()
        pen.setWidthF(line_width)
        self.disc.setPen(pen)
        self._visible = 1

    def x(self) -> float:
        return self._pos.x()

    def y(self) -> float:
        return self._pos.y()

    def set_text(self, text: str):
        self.text.setPlainText(text)

    # The following functions are for animation support

    @pyqtProperty(QPointF)
    def pos(self):
        return self._pos

    @pos.setter
    def pos(self, value):
        self.rect = QRectF(value.x() - self._radius, value.y() - self._radius, 2 * self._radius, 2 * self._radius)
        self.disc.setRect(self.rect)
        self.text.setPos(QPointF(value.x() - 1.8, value.y() + 1.8))
        self._pos = value

    @pyqtProperty(int)
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, value):
        if value > 0:
            self.disc.show()
            self.text.show()
        else:
            self.disc.hide()
            self.text.hide()
        self._visible = value
