from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtOpenGL import QGLWidget, QGLFormat, QGL
from PyQt5.QtWidgets import (QApplication, QGraphicsView,
                             QGraphicsPixmapItem, QGraphicsScene, QGraphicsPolygonItem,
                             QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsTextItem, QOpenGLWidget)
from PyQt5.QtGui import QPainter, QPixmap, QPolygonF, QPen, QVector3D, QPalette
from PyQt5.QtCore import (QObject, QPointF, QPoint, QRectF,
                          QPropertyAnimation, pyqtProperty, QSequentialAnimationGroup,
                          QParallelAnimationGroup, QPauseAnimation, Qt)
from gui.RDiscRobot import RDiscRobot

from gui.RPolygon import RPolygon
from gui.RDisc import RDisc
from gui.RSegment import RSegment
from gui.RText import RText
import time


class MainWindowPlus(QtWidgets.QMainWindow):
    def __init__(self, gui):
        super().__init__()
        self.gui = gui

    # Adjust zoom level/scale on +/- key press
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Plus:
            self.gui.zoom /= 0.9
        if event.key() == QtCore.Qt.Key_Minus:
            self.gui.zoom *= 0.9
        self.gui.redraw()


class GUI(object):
    width = 1600
    height = 1000
    zoom = 50.0
    base_line_width = 1
    animation_finished_action = lambda: None

    def __init__(self):
        MainWindow = MainWindowPlus(self)
        self.setupUi(MainWindow)

    def setupUi(self, MainWindow):
        self.MainWindow = MainWindow
        self.sequence = QSequentialAnimationGroup()
        self.sequence.finished.connect(self.animation_finished)
        self.scene = QGraphicsScene()

        MainWindow.setObjectName("MainWindow")
        # MainWindow.setWindowIcon(QtGui.QIcon("icon.png"))
        MainWindow.resize(self.width, self.height)

        # qt designer generated code
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.graphicsView.sizePolicy().hasHeightForWidth())
        self.graphicsView.setSizePolicy(sizePolicy)
        self.graphicsView.setObjectName("graphicsView")
        self.gridLayout.addWidget(self.graphicsView, 3, 1, 1, 1)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 3, 0, 1, 1)
        self.pushButton_1 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_1.setObjectName("pushButton_1")
        self.gridLayout_2.addWidget(self.pushButton_1, 8, 0, 1, 1)
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setObjectName("pushButton_4")
        self.gridLayout_2.addWidget(self.pushButton_4, 14, 0, 1, 1)
        self.label_1 = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_1.sizePolicy().hasHeightForWidth())
        self.label_1.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_1.setFont(font)
        self.label_1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_1.setObjectName("label_1")
        self.gridLayout_2.addWidget(self.label_1, 1, 0, 1, 1)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.gridLayout_2.addWidget(self.lineEdit_2, 9, 0, 1, 1)
        self.lineEdit_5 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.gridLayout_2.addWidget(self.lineEdit_5, 15, 0, 1, 1)
        self.lineEdit_0 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_0.setObjectName("lineEdit_0")
        self.gridLayout_2.addWidget(self.lineEdit_0, 5, 0, 1, 1)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout_2.addWidget(self.pushButton_2, 10, 0, 1, 1)
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setObjectName("pushButton_3")
        self.gridLayout_2.addWidget(self.pushButton_3, 12, 0, 1, 1)
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.gridLayout_2.addWidget(self.lineEdit_4, 13, 0, 1, 1)
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.gridLayout_2.addWidget(self.lineEdit_3, 11, 0, 1, 1)
        self.label_0 = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_0.sizePolicy().hasHeightForWidth())
        self.label_0.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_0.setFont(font)
        self.label_0.setAlignment(QtCore.Qt.AlignCenter)
        self.label_0.setObjectName("label_0")
        self.gridLayout_2.addWidget(self.label_0, 0, 0, 1, 1)
        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_5.setObjectName("pushButton_5")
        self.gridLayout_2.addWidget(self.pushButton_5, 16, 0, 1, 1)
        self.pushButton_7 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_7.setObjectName("pushButton_7")
        self.gridLayout_2.addWidget(self.pushButton_7, 24, 0, 1, 1)
        self.lineEdit_1 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_1.setObjectName("lineEdit_1")
        self.gridLayout_2.addWidget(self.lineEdit_1, 7, 0, 1, 1)
        self.lineEdit_7 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_7.setObjectName("lineEdit_7")
        self.gridLayout_2.addWidget(self.lineEdit_7, 22, 0, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 2, 0, 1, 1)
        self.lineEdit_6 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.gridLayout_2.addWidget(self.lineEdit_6, 17, 0, 1, 1)
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_6.setObjectName("pushButton_6")
        self.gridLayout_2.addWidget(self.pushButton_6, 19, 0, 1, 1)
        self.pushButton_0 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_0.setObjectName("pushButton_0")
        self.gridLayout_2.addWidget(self.pushButton_0, 6, 0, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.gridLayout_2.addWidget(self.label_4, 4, 0, 1, 1)
        self.gridLayout.addLayout(self.gridLayout_2, 3, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # end of eq designer generated code

        self.lineEdits = []
        self.lineEdits.append(self.lineEdit_0)
        self.lineEdits.append(self.lineEdit_1)
        self.lineEdits.append(self.lineEdit_2)
        self.lineEdits.append(self.lineEdit_3)
        self.lineEdits.append(self.lineEdit_4)
        self.lineEdits.append(self.lineEdit_5)
        self.lineEdits.append(self.lineEdit_6)
        self.lineEdits.append(self.lineEdit_7)
        self.pushButtons = []
        self.pushButtons.append(self.pushButton_0)
        self.pushButtons.append(self.pushButton_1)
        self.pushButtons.append(self.pushButton_2)
        self.pushButtons.append(self.pushButton_3)
        self.pushButtons.append(self.pushButton_4)
        self.pushButtons.append(self.pushButton_5)
        self.pushButtons.append(self.pushButton_6)
        self.pushButtons.append(self.pushButton_7)
        self.labels = []
        self.labels.append(self.label_0)
        self.labels.append(self.label_1)
        self.labels.append(self.label_2)
        self.labels.append(self.label_3)
        self.labels.append(self.label_4)
        self.graphicsView.setScene(self.scene)
        self.graphicsView.setSceneRect(0, 0, 0, 0)
        self.graphicsView.setRenderHints(QPainter.Antialiasing)
        # self.graphicsView.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)
        self.graphicsView.setViewport(QGLWidget(QGLFormat(QGL.SampleBuffers)))
        self.graphicsView.scale(self.zoom, -self.zoom)
        self.graphicsView.setDragMode(1)

    # Add a disc to the scene with radius r centered at (x, y) and return the object associated with it
    def add_disc(self, r, x, y, fill_color=QtCore.Qt.black):
        d = RDisc(r, x, y, fill_color, line_width=self.base_line_width / self.zoom)
        self.scene.addItem(d.disc)
        return d

    # Add a disc robot to the scene with radius r centered at (x, y) and return the object associated with it
    def add_disc_robot(self, r, x, y, text="", fill_color=QtCore.Qt.black):
        d = RDiscRobot(r, x, y, fill_color, line_width=self.base_line_width / self.zoom, text=text)
        self.scene.addItem(d.disc)
        self.scene.addItem(d.text)
        return d

    # Add a polygon to the scene and return the object associated with it
    def add_polygon(self, points, fill_color=QtCore.Qt.black):
        p = RPolygon(points, fill_color, line_width=self.base_line_width / self.zoom)
        self.scene.addItem(p.polygon)
        return p

    # Add a segment to the scene and return the object associated with it
    def add_segment(self, x1, y1, x2, y2, line_color=QtCore.Qt.black):
        s = RSegment(x1, y1, x2, y2, line_color, line_width=self.base_line_width / self.zoom)
        self.scene.addItem(s.line)
        return s

    def add_text(self, text, x, y, size, color=QtCore.Qt.black):
        t = RText(text, x, y, size, color)
        self.scene.addItem(t.text)
        return t

    # Create a new linear translation animation for obj starting at ix, iy and ending at x, y
    def linear_translation_animation(self, obj, ix, iy, x, y, duration=1000):
        anim = QPropertyAnimation(obj, b'pos')
        anim.setDuration(duration)
        anim.setStartValue(QPointF(ix, iy))
        anim.setEndValue(QPointF(x, y))
        return anim

    # Create a general translation animation for obj. func is path from the unit interval I to R^2
    def translation_animation(self, obj, func, duration=1000):
        anim = QPropertyAnimation(obj, b'pos')
        anim.setDuration(duration)
        anim.setStartValue(QPointF(func(0)[0], func(0)[1]))
        anim.setEndValue(QPointF(func(1)[0], func(1)[1]))
        vals = [p / 100 for p in range(0, 101)]
        for i in vals:
            anim.setKeyValueAt(i, (QPointF(func(i)[0], func(i)[1])))
        return anim

    # Create an animation the changes the visibility of an object
    def visibility_animation(self, obj, visible):
        anim = QPropertyAnimation(obj, b'visible')
        anim.setDuration(0)
        if (visible):
            anim.setEndValue(1)
        else:
            anim.setEndValue(0)
        return anim

    # Create an animation that does nothing
    def pause_animation(self, duration=1000):
        anim = QPauseAnimation(duration)
        return anim

    # Create an animation from a set of animations that will run in parallel
    def parallel_animation(self, *animations):
        group = QParallelAnimationGroup()
        for anim in animations:
            group.addAnimation(anim)
        return group

    # Add an animation to the animation queue
    def queue_animation(self, *animations):
        for anim in animations:
            self.sequence.addAnimation(anim)

    # Play (and empty) the animation queue
    def play_queue(self):
        self.sequence.start()

    # Empty the animation queue queue
    def empty_queue(self):
        self.sequence.clear()

    # Clear the scene of all objects
    def clear_scene(self):
        self.scene.clear()

    # Redraw the scene with updated parameters
    def redraw(self):
        line_width = self.base_line_width / self.zoom
        for item in self.graphicsView.items():
            if not isinstance(item, QGraphicsTextItem):
                pen = item.pen()
                pen.setWidthF(line_width)
                item.setPen(pen)
        self.graphicsView.resetTransform()
        self.graphicsView.scale(self.zoom, -self.zoom)

    def animation_finished(self):
        self.empty_queue()
        print("Finished playing animation")
        self.animation_finished_action()

    def set_animation_finished_action(self, action):
        self.animation_finished_action = action

    # Set the i'th text of field in the GUI
    def set_field(self, i, s):
        self.lineEdits[i].setText(s)

    # Get the text of the i'th text field in the GUI
    def get_field(self, i):
        return self.lineEdits[i].text()

    # Set the text and color of the i'th label in the GUI
    def set_label(self, i, s, color=Qt.black):
        self.labels[i].setText(s)
        palette = self.labels[i].palette()
        palette.setColor(QPalette.WindowText, color)
        self.labels[i].setPalette(palette)

    # Set the function to be called when the i'th button in the GUI is pressed
    def set_logic(self, i, logic):
        try:
            self.pushButtons[i].clicked.disconnect()
        except Exception:
            pass
        self.pushButtons[i].clicked.connect(logic)

    # Set the i'th button text in the GUI
    def set_button_text(self, i, s):
        self.pushButtons[i].setText(s)

    # Set the program's name
    def set_program_name(self, s):
        self.MainWindow.setWindowTitle(s)
